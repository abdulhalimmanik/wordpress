<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}


if ( !class_exists( 'Thim_SC_Testimonials' ) ) {

	class Thim_SC_Testimonials {

		/**
		 * Shortcode name
		 * @var string
		 */
		protected $name = '';

		/**
		 * Shortcode description
		 * @var string
		 */
		protected $description = '';

		/**
		 * Shortcode base
		 * @var string
		 */
		protected $base = '';


		public function __construct() {

			//======================== CONFIG ========================
			$this->name        = esc_attr__( 'Thim Testimonials', 'hotel-wp' );
			$this->description = esc_attr__( 'Display Testimonials', 'hotel-wp' );
			$this->base        = 'testimonials';
			//====================== END: CONFIG =====================


			$this->map();
			add_shortcode( 'thim-' . $this->base, array( $this, 'shortcode' ) );


			//add_action( 'wp_ajax_thim_sc_our_gallery', array( $this, 'get_list_images' ) );
			//add_action( 'wp_ajax_nopriv_thim_sc_our_gallery', array( $this, 'get_list_images' ) );

		}

		/**
		 * vc map shortcode
		 */
		public function map() {
			vc_map( array(
					'name'        => $this->name,
					'base'        => 'thim-' . $this->base,
					'category'    => esc_attr__( 'Thim Shortcodes', 'hotel-wp' ),
					'description' => $this->description,
					'params'      => array(
						array(
							"type"        => "textfield",
							"admin_label" => true,
							"heading"     => esc_html__( "Block Title", "hotel-wp" ),
							"param_name"  => "title",
							"dependency"  => array(
								"element" => "layout",
								"value"   => "default",
							),
							"description" => esc_html__( "Write the title for the block.", "hotel-wp" )
						),

						array(
							"type"        => "number",
							"min"         => "1",
							"value"       => "3",
							"admin_label" => true,
							"heading"     => esc_html__( "Number testimonials", 'hotel-wp' ),
							"param_name"  => "number-posts",
							'description' => esc_html__( '', 'hotel-wp' )
						),

						array(
							"type"        => "dropdown",
							"admin_label" => true,
							"heading"     => esc_html__( "Layout", "hotel-wp" ),
							"param_name"  => "layout",
							"value"       => array(
								esc_html__( "Default", "hotel-wp" )  => "default",
								esc_html__( "Layout 2", "hotel-wp" ) => "layout-2",
							),
							"std"         => "default",
							"description" => esc_attr__( "", "hotel-wp" )
						),

						array(
							"type"        => "dropdown",
							"admin_label" => true,
							"heading"     => esc_attr__( "Style", "hotel-wp" ),
							"param_name"  => "style",
							"value"       => array(
								esc_html__( "Left style", "hotel-wp" )   => "left",
								esc_html__( "Center style", "hotel-wp" ) => "center",
							),
							"std"         => "left",
							"dependency"  => array(
								"element" => "layout",
								"value"   => "default",
							),
							"description" => esc_attr__( "", "hotel-wp" )
						),

						array(
							"admin_label" => true,
							"type"        => "dropdown",
							"admin_label" => true,
							"heading"     => esc_attr__( "Auto Play Speed", "hotel-wp" ),
							"param_name"  => "auto",
							"value"       => array(
								esc_html__( "Yes", "hotel-wp" )  => "true",
								esc_html__( "No", "hotel-wp" ) => "false",
							),
							"std"         => "left",
							"dependency"  => array(
								"element" => "layout",
								"value"   => "default",
							)
						),

						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Animation", "hotel-wp" ),
							"param_name"  => "css_animation",
							"admin_label" => true,
							"value"       => array(
								esc_html__( "No", "hotel-wp" )                 => "no",
								esc_html__( "Top to bottom", "hotel-wp" )      => "slideInDown",
								esc_html__( "Bottom to top", "hotel-wp" )      => "slideInUp",
								esc_html__( "Left to right", "hotel-wp" )      => "slideInLeft",
								esc_html__( "Right to left", "hotel-wp" )      => "slideInRight",
								esc_html__( "Appear from center", "hotel-wp" ) => "zoomIn"
							),
							"std"         => "no",
							"description" => esc_html__( "Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "hotel-wp" ),

						),


						array(
							'type'        => 'textfield',
							'admin_label' => true,
							'heading'     => esc_html__( 'Extra class', 'hotel-wp' ),
							'param_name'  => 'el_class',
							'value'       => '',
							'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp' ),
						),

					)
				)
			);
		}

		/**
		 * Add shortcode
		 *
		 * @param $atts
		 */
		public function shortcode( $atts ) {

			$params = shortcode_atts( array(
				'title'          => '',
				'sub-title'      => '',
				'number-posts'   => '3',
				'images-visible' => '3',
				'layout'         => 'default',
				'style'          => 'left',
				'css_animation'  => 'no',
				'el_class'       => '',
				'auto'           => '',
			), $atts );

			$params['sc-name'] = $this->base;


			$testimonials_args = array(
				'post_type'           => 'testimonials',
				'posts_per_page'      => $params['number-posts'],
				'ignore_sticky_posts' => true,
			);

			$testimonials_qurey = new WP_Query( $testimonials_args );


			ob_start();

			if ( isset( $params['layout'] ) && $params['layout'] == 'layout-2' ) {
				include THIM_SC_PATH . '/testimonials/tpl/layout-2.php';
			} else {
				include THIM_SC_PATH . '/testimonials/tpl/default.php';
			}

			/*echo '<pre>';
			print_r($show_testimonials_qurey);
			echo '</pre>';*/

			$html = ob_get_contents();
			ob_end_clean();

			return $html;

		}

	}

	new Thim_SC_Testimonials();
}

