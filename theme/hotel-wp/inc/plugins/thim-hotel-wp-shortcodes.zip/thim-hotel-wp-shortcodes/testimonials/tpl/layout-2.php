<?php

$css_animation = esc_attr($params['css_animation']);
$title     = $params['title'];
$sub_title = $params['sub-title'];
$auto = esc_attr($params['auto']);
$number_testimonials = esc_attr($params['number-posts']);

$img_link_default = get_bloginfo('template_directory') . '/assets/images/testimonials-default.jpg';


?>
<div class="thim-testimonials-wrap">

    <div class="thim-testimonials owl-carousel owl-theme" data-auto="<?php echo empty($auto)? 0 : $auto; ?>" data-animation="<?php echo $css_animation; ?>" data-testimonials="<?php echo $number_testimonials; ?>">
		<?php if ( $testimonials_qurey->have_posts() ) : while ( $testimonials_qurey->have_posts() ) : $testimonials_qurey->the_post(); ?>

            <div class="testimonials-item">
                <div class="rating"></div>
                <p class="content"><?php echo get_the_content(); ?></p>
                <div class="title"><?php echo get_the_title(); ?></div>
				<?php
				$regency = get_post_meta( get_the_ID(), 'regency', true );
				if ( $regency ) {
					?>
                    <div class="regency"><?php echo get_post_meta( get_the_ID(), 'regency', true ); ?></div>
					<?php
				}
				?>
            </div>


		<?php endwhile;
			wp_reset_postdata();
		endif; ?>
    </div>


    <div class="thim-testimonial-custom-dots owl-carousel owl-theme">

		<?php if ( $testimonials_qurey->have_posts() ) : while ( $testimonials_qurey->have_posts() ) : $testimonials_qurey->the_post(); ?>
            <div class="img-dot">
				<?php if ( has_post_thumbnail() ) : ?>
                    <img src="<?php echo thim_aq_resize( get_the_post_thumbnail_url(), 72, 72, true ) ?>">
				<?php else: ?>
                    <img src="<?php echo $img_link_default; ?>"/>
				<?php endif; ?>
            </div>
		<?php endwhile;
			wp_reset_postdata();
		endif; ?>
    </div>

</div>
