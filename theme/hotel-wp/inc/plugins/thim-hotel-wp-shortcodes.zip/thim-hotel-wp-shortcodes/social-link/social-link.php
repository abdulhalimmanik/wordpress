<?php
/**
 * Social link shortcode
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * include template
 */
include_once 'tpl/default.php';


/**
 * Map shortcode
 */
vc_map(array(
    "name" => esc_html__("Thim Social Link", "hotel-wp"),
    "base" => "thim_social_link",
    "class" => "",
    "icon" => "icon-wpb-icon_social_link",
    'description' => esc_html__('Display social link.', 'hotel-wp'),
    "category" => esc_html__('Thim Shortcodes', 'hotel-wp'),
    "params" => array(
        // Style
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style", "hotel-wp"),
            "param_name" => "style",
            "admin_label" => true,
            "value" => array(
                esc_html__("Style 01", "hotel-wp") => "style-01",
                esc_html__("Style 02", "hotel-wp") => "style-02",
                esc_html__("Style 03", "hotel-wp") => "style-03"
            ),
        ),
        //Alignment
        array(
            'type' => 'dropdown',
            'admin_label' => true,
            'heading' => esc_html__('Icon Alignment', 'hotel-wp'),
            'param_name' => 'alignment',
            'value' => array(
                'Choose the icons alignment' => '',
                esc_html__('Icons at left', 'hotel-wp') => 'left',
                esc_html__('Icons at center', 'hotel-wp') => 'center',
                esc_html__('Icons at right', 'hotel-wp') => 'right',
            ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Facebook", "hotel-wp"),
            "param_name" => "link_face",
            "value" => '#',
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Twitter", "hotel-wp"),
            "param_name" => "link_twitter",
            "value" => '#',
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Skype", "hotel-wp"),
            "param_name" => "link_skype",
            "value" => '#',
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Pinterest", "hotel-wp"),
            "param_name" => "link_pinterest",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Google", "hotel-wp"),
            "param_name" => "link_google",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Dribble", "hotel-wp"),
            "param_name" => "link_dribble",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Linkedin", "hotel-wp"),
            "param_name" => "link_linkedin",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Digg", "hotel-wp"),
            "param_name" => "link_digg",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Youtube", "hotel-wp"),
            "param_name" => "link_youtube",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link Instagram", "hotel-wp"),
            "param_name" => "link_instagram",
        ),
        //open
        array(
            'type' => 'dropdown',
            'admin_label' => true,
            'heading' => esc_html__('Open Tab', 'hotel-wp'),
            'param_name' => 'tab',
            'value' => array(
                esc_html__('New Tab', 'hotel-wp') => '_blank',
                esc_html__('Same Tab', 'hotel-wp') => '',
            ),
        ),
    )
));