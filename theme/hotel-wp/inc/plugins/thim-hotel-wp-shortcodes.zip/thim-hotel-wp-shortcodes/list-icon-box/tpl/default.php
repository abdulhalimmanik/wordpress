<div class="thim-sc-list-icon-box">
	<div class="list-icon-box-wrapper <?php echo esc_attr( $params['el_class'] ); ?>">
	<?php
	echo '<ul class="list-icon-box owl-carousel owl-theme">';
	foreach ( $params['list_icon_box'] as $list_icon_box ) {
		//Icon font type
		$icon_font = '';
		if ( $list_icon_box['icon_fontawesome'] ) {
			$icon_font = 'class = "' . $list_icon_box['icon_fontawesome'] . ' " ';
		}
		if ( $list_icon_box['icon_openiconic'] ) {
			$icon_font = 'class = "' . $list_icon_box['icon_openiconic'] . ' " ';
		}
		if ( $list_icon_box['icon_typicons'] ) {
			$icon_font = 'class = "' . $list_icon_box['icon_typicons'] . ' " ';
		}
		if ( $list_icon_box['icon_entypo'] ) {
			$icon_font = 'class = "' . $list_icon_box['icon_entypo'] . ' " ' ;
		}
		if ( $list_icon_box['icon_linecons'] ) {
			$icon_font = 'class = "' . $list_icon_box['icon_linecons'] . ' " ';
		}
		if ( $list_icon_box['icon_ionicons'] ) {
			$icon_font = 'class = "' . $list_icon_box['icon_ionicons'] . ' " ';
		}

		$link_array  = vc_build_link( $list_icon_box['button_link'] );
		$button_link = '';
		if ( $link_array['url'] ) {
			$button_link .= 'href="' . esc_url( $link_array['url'] ) . '"';
		}
		if ( $link_array['title'] ) {
			$button_link .= ' title="' . esc_attr( $link_array['title'] ) . '"';
		}

		$but_display = '';
		if ( $list_icon_box['button_display'] == 'yes' ) {
			$but_display .= 'display: inline-block ;';
		} else {
			$but_display .= 'display: none;';
		}
		if ( $but_display ) {
			$but_display = ' style="' . $but_display . '"';
		}
		
		if ( $list_icon_box['title'] ) {
			echo '<li class="box-item">';
			echo '<i '.$icon_font.'></i>';
			echo '<h5 class="box-title">' . $list_icon_box['title'] . '</h5>';
			echo '<p class="description">' . $list_icon_box['description'] . '</p>';
			echo '<a '.$but_display.' ' . $button_link . '>' . esc_attr( $list_icon_box['button_value'] ) . '</a>';
			echo '</li>';
		}
	}
	echo '</ul>';
	?>
	</div>
</div>