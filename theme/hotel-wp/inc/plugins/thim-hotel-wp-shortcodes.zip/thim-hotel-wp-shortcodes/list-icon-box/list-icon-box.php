<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Thim_SC_List_Icon_Box' ) ) {

	class Thim_SC_List_Icon_Box {

		/**
		 * Shortcode name
		 * @var string
		 */
		protected $name = '';

		/**
		 * Shortcode description
		 * @var string
		 */
		protected $description = '';

		/**
		 * Shortcode base
		 * @var string
		 */
		protected $base = '';


		public function __construct() {

			//======================== CONFIG ========================
			$this->name        = esc_attr__( 'Thim List Icon Box', 'hotel-wp' );
			$this->description = esc_attr__( 'Display list icon box', 'hotel-wp' );
			$this->base        = 'list-icon-box';
			//====================== END: CONFIG =====================


			$this->map();
			add_shortcode( 'thim-' . $this->base, array( $this, 'shortcode' ) );
		}

		/**
		 * vc map shortcode
		 */
		public function map() {
			vc_map( array(
					'name'        => $this->name,
					'base'        => 'thim-' . $this->base,
					'category'    => esc_attr__( 'Thim Shortcodes', 'hotel-wp' ),
					'description' => $this->description,
					'params'      => array(
						array(
							'type'       => 'param_group',
							'value'      => '',
							'param_name' => 'list_icon_box',
							'params'     => array(
								//Title
								array(
									'type'        => 'textfield',
									'admin_label' => true,
									'heading'     => esc_html__( 'Title', 'hotel-wp' ),
									'param_name'  => 'title',
									'value'       => '',
									'description' => esc_html__( 'Write the title value', 'hotel-wp' ),
								),
								//Description
								array(
									'type'        => 'textfield',
									'admin_label' => true,
									'heading'     => esc_html__( 'Description', 'hotel-wp' ),
									'param_name'  => 'description',
									'value'       => '',
									'description' => esc_html__( 'Write the description value', 'hotel-wp' ),
								),
								// Icon type
								array(
									'type'        => 'dropdown',
									'heading'     => esc_html__( 'Icon type', 'hotel-wp' ),
									'value'       => array(
										esc_html__( 'Choose icon type', 'hotel-wp' ) => '',
										esc_html__( 'Font Awesome', 'hotel-wp' )     => 'fontawesome',
										esc_html__( 'Openiconic', 'hotel-wp' )       => 'openiconic',
										esc_html__( 'Typicons', 'hotel-wp' )         => 'typicons',
										esc_html__( 'Entypo', 'hotel-wp' )           => 'entypo',
										esc_html__( 'Linecons', 'hotel-wp' )         => 'linecons',
										esc_html__( 'Ionicons', 'hotel-wp' ) 		=> 'ionicons',
									),
									'admin_label' => true,
									'param_name'  => 'icon_type',
									'description' => esc_html__( 'Select icon type.', 'hotel-wp' ),
								),
								// Icon type: Fontawesome - Icon picker
								array(
									'type'        => 'iconpicker',
									'admin_label' => true,
									'heading'     => esc_html__( 'Icon', 'hotel-wp' ),
									'param_name'  => 'icon_fontawesome',
									'value'       => 'fa fa-heart',
									'settings'    => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 50,
									),
									'dependency'  => array(
										'element' => 'icon_type',
										'value'   => 'fontawesome',
									),
									'description' => esc_html__( 'FontAwesome library.', 'hotel-wp' ),
								),
								// Icon type: Openiconic - Icon picker
								array(
									'type'        => 'iconpicker',
									'admin_label' => true,
									'heading'     => esc_html__( 'Icon', 'hotel-wp' ),
									'param_name'  => 'icon_openiconic',
									'value'       => '',
									'settings'    => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 50,
										'type'         => 'openiconic',
									),
									'dependency'  => array(
										'element' => 'icon_type',
										'value'   => 'openiconic',
									),
									'description' => esc_html__( 'Openiconic library.', 'hotel-wp' ),
								),
								// Icon type: Typicons - Icon picker
								array(
									'type'        => 'iconpicker',
									'admin_label' => true,
									'heading'     => esc_html__( 'Icon', 'hotel-wp' ),
									'param_name'  => 'icon_typicons',
									'value'       => '',
									'settings'    => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 50,
										'type'         => 'typicons',
									),
									'dependency'  => array(
										'element' => 'icon_type',
										'value'   => 'typicons',
									),
									'description' => esc_html__( 'Typicons library.', 'hotel-wp' ),
								),
								// Icon type: Entypo - Icon picker
								array(
									'type'        => 'iconpicker',
									'admin_label' => true,
									'heading'     => esc_html__( 'Icon', 'hotel-wp' ),
									'param_name'  => 'icon_entypo',
									'value'       => '',
									'settings'    => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 50,
										'type'         => 'entypo',
									),
									'dependency'  => array(
										'element' => 'icon_type',
										'value'   => 'entypo',
									),
									'description' => esc_html__( 'Entypo library.', 'hotel-wp' ),
								),
								// Icon type: Lincons - Icon picker
								array(
									'type'        => 'iconpicker',
									'admin_label' => true,
									'heading'     => esc_html__( 'Icon', 'hotel-wp' ),
									'param_name'  => 'icon_linecons',
									'value'       => '',
									'settings'    => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 50,
										'type'         => 'linecons',
									),
									'dependency'  => array(
										'element' => 'icon_type',
										'value'   => 'linecons',
									),
									'description' => esc_html__( 'Linecons library.', 'hotel-wp' ),
								),
								// Icon type: Ionicons - Icon picker
								array(
									'type'        => 'iconpicker',
									'admin_label' => true,
									'heading'     => esc_html__( 'Icon', 'hotel-wp' ),
									'param_name'  => 'icon_ionicons',
									'value'       => '',
									'settings'    => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 50,
										'type'         => 'ionicons',
									),
									'dependency'  => array(
										'element' => 'icon_type',
										'value'   => 'ionicons',
									),
									'description' => esc_html__( 'Ionicons library.', 'hotel-wp' ),
								),
								//Display the button?
								array(
									'type'        => 'checkbox',
									'heading'     => esc_html__( 'Display the button?', 'hotel-wp' ),
									'param_name'  => 'button_display',
									'value'       => array( esc_html__( '', 'hotel-wp' ) => 'yes' ),
									'description' => esc_html__( 'Tick it to display the button.', 'hotel-wp' ),
								),
								//Button link
								array(
									'type'        => 'vc_link',
									'heading'     => esc_html__( 'Button link', 'hotel-wp' ),
									'param_name'  => 'button_link',
									'value'       => '',
									'description' => esc_html__( 'Write the button link', 'hotel-wp' ),
									'dependency'  => array(
										'element' => 'button_display',
										'value'   => 'yes',
									),
								),
								//Button value
								array(
									'type'        => 'textfield',
									'admin_label' => true,
									'heading'     => esc_html__( 'Button value', 'hotel-wp' ),
									'param_name'  => 'button_value',
									'value'       => '',
									'description' => esc_html__( 'Write the button value', 'hotel-wp' ),
									'dependency'  => array(
										'element' => 'button_display',
										'value'   => 'yes',
									),
								),
							)
						),
						array(
							'type'        => 'textfield',
							'admin_label' => true,
							'heading'     => esc_attr__( 'Extra class name', 'hotel-wp' ),
							'param_name'  => 'el_class',
							'value'       => '',
							'description' => esc_attr__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'hotel-wp' ),
						),
					)
				)
			);
		}

		/**
		 * Add shortcode
		 *
		 * @param $atts
		 */
		public function shortcode( $atts ) {

			$params = shortcode_atts( array(
				'list_icon_box' => '',
				'el_class'     => '',
			), $atts );

			$params['list_icon_box'] = vc_param_group_parse_atts( $params['list_icon_box'] );

			ob_start();

			include THIM_SC_PATH . $this->base . '/tpl/default.php';

			$html = ob_get_contents();
			ob_end_clean();

			return $html;

		}

	}

	new Thim_SC_List_Icon_Box();
}
