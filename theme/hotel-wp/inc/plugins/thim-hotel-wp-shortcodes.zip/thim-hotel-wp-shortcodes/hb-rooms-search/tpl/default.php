<?php
/**
 * Shortcode List Events
 *
 * @param $atts
 *
 * @return string
 */

add_shortcode( 'thim-hb-rooms-search', 'thim_shortcode_hb_rooms_search' );

function thim_shortcode_hb_rooms_search( $atts )
{
	$rooms_search = shortcode_atts(array(
		'style' => '',
		'contact_info' => '',
		'text' => '',
		'css_animation' => '',
		'el_class' => '',
	), $atts);

	$html = '';
	$css_animation = thim_getCSSAnimation($rooms_search['css_animation']);
	$datetime = new DateTime('NOW');
	$tomorrow = new DateTime('tomorrow');
	$search = hb_get_page_permalink('search'); // hb_get_url()
	$check_in_date = hb_get_request('check_in_date');
	$check_out_date = hb_get_request('check_out_date');

	$format = get_option( 'date_format' );

	if ( $check_in_date == '' ) {
		$check_in_date = '' . $datetime->format( $format );
	}
	if ( $check_out_date == '' ) {
		$check_out_date = $tomorrow->format( $format );
	}

	$adults = hb_get_request('adults', 1);
	$max_child = hb_get_request( 'max_child', 1 );
	$uniqid = uniqid();

	$html .= '<div class="thim-sc-hb-rooms-search '.$rooms_search['style'].' ' . $rooms_search['el_class'] . ' ' . $css_animation . '">';
	if ($rooms_search['style'] == 'box') {
		$html .= '<div id="hotel-booking-search-' . uniqid() . '" class="hotel-booking-search layout-box">';

		$html .= '<form name="hb-search-form" action="' . esc_url($search) . '" class="hb-search-form-' . esc_attr($uniqid) . '">';
		$html .= '<ul class="hb-form-table">';

		$html .= '<li class="hb-form-field">';
		$html .= '<h5 class="label">' . esc_html__('Check in', 'hotel-wp') . '</h5>';
		$html .= '<div class="hb-form-field-input hb_input_field">';
		$html .= '<input class="month" readonly type="text" value="' . esc_attr(date("F")) . '" />';
		$html .= '<input type="text" class="day" value="' . $datetime->format('d') . '" readonly />';
		$html .= '<input type="text" name="check_in_date" id="check_in_date_' . esc_attr($uniqid) . '" class="check-date" value="' . esc_attr($check_in_date) . '" readonly />';
		$html .= '</div>';
		$html .= '</li>';

		$html .= '<li class="hb-form-field">';
		$html .= '<h5 class="label">' . esc_html__('Check out', 'hotel-wp') . '</h5>';
		$html .= '<div class="hb-form-field-input hb_input_field">';
		$html .= '<input class="month" readonly  type="text" value="' . esc_attr(date("F")) . '" />';
		$html .= '<input type="text" class="day" value="' . $tomorrow->format('d') . '" readonly />';
		$html .= '<input type="text" name="check_out_date" id="check_out_date_' . esc_attr($uniqid) . '" class="check-date" value="' . esc_attr($check_out_date) . '" readonly/>';
		$html .= '</div>';
		$html .= '</li>';

		$html .= '<li class="hb-form-field">';
		$html .= '<h5 class="label">' . esc_html__('Guests', 'hotel-wp') . '</h5>';
		$html .= '<div class="hb-form-field-input hb-guest-field">';
		$html .= '<span class="goUp"><i class="icomoon icon-up"></i></span>';

		ob_start();
		hb_dropdown_numbers(
			array(
				'name' => 'adults_capacity',
				'min' => 1,
				'max' => hb_get_max_capacity_of_rooms(),
				'selected' => $adults,
				'option_none_value' => 0,
				'options' => hb_get_capacity_of_rooms()
			)
		);
		$html .= ob_get_clean();

		$html .= '<span class="goDown"><i class="icomoon icon-up"></i></span>';
		$html .= '</div>';
		$html .= '</li>';

		$html .= '</ul>';

		ob_start();
		wp_nonce_field('hb_search_nonce_action', 'nonce');
		$html .= ob_get_clean();

		$html .= '<input type="hidden" name="hotel-booking" value="results" />';
		$html .= '<input type="hidden" name="action" value="hotel_booking_parse_search_params" />';
		$html .= '<p class="hb-submit">';
		$html .= '<button type="submit">' . esc_html__('Check Availability', 'hotel-wp') . '</button>';
		$html .= '</p>';

		$html .= '</form>';
		$html .= '</div>';
	} else if ( $rooms_search['style'] == 'special' ) {
		$html .= '<div id="hotel-booking-search-' . uniqid() . '" class="hotel-booking-search layout-special">';

		$html .= '<form name="hb-search-form" action="' . esc_url($search) . '" class="hb-search-form-' . esc_attr($uniqid) . '">';
		$html .= '<ul class="hb-form-table">';
		$html .= '<input type="text" id="multidate" class="multidate" value="' . esc_attr($check_in_date) . '" readonly />';
		$html .= '<li class="hb-form-field hb-form-check-in">';
		$html .= '<div class="label">' . esc_html__('Check-In', 'hotel-wp') . '</div>';
		$html .= '<div class="hb-form-field-input hb_input_field">';
		$html .= '<input type="text" id="day" class="day" value="' . $datetime->format('d') . '" readonly />';
		$html .= '<input id="month" class="month" readonly type="text" value="' . $datetime->format('M') . '. ' . $datetime->format('Y') . '" />';

		$html .= '<input type="hidden" name="check_in_date" id="check_in_date_' . esc_attr($uniqid) . '" class="check-date" value="' . esc_attr($check_in_date) . '" readonly />';
		$html .= '</div>';
		$html .= '</li>';

		$html .= '<li class="hb-form-field hb-form-check-out">';
		$html .= '<div class="label">' . esc_html__('Check-Out', 'hotel-wp') . '</div>';
		$html .= '<div class="hb-form-field-input hb_input_field">';
		$html .= '<input type="text" id="day2" class="day" value="' . $tomorrow->format('d') . '" readonly />';
		$html .= '<input id="month2" class="month" readonly  type="text" value="' .$tomorrow->format('M') . '. ' . $tomorrow->format('Y') . '" />';

		$html .= '<input type="hidden" name="check_out_date" id="check_out_date_' . esc_attr($uniqid) . '" class="check-date" value="' . esc_attr($check_out_date) . '" readonly/>';
		$html .= '</div>';
		$html .= '</li>';

		$html .= '<li class="hb-form-field hb-form-number">';
		$html .= '<div class="label">' . esc_html__('Number', 'hotel-wp') . '</div>';
		$html .= '<div id="guests" class="hb-form-field-input hb_input_field">';
		$html .= '<input type="text" id="number" class="day" value="01" readonly />';
		$html .= '<input class="month" readonly  type="text" value="' .esc_html__('Guests','hotel-wp'). '" />';
		$html .= '</div>';
		$html .= '<div class="hb-form-field-list">';
			$html .= '<div class="hb-form-field-input hb-guest-field">';
			ob_start();
			hb_dropdown_numbers(
				array(
					'name' => 'adults_capacity',
					'min' => 1,
					'max' => hb_get_max_capacity_of_rooms(),
					'option_none_value' => 0,
					'selected' => $adults,
					'options' => hb_get_capacity_of_rooms()
				)
			);
			$html .= ob_get_clean();
			$html .= ' <span class="name">'.esc_html__('Guests','hotel-wp').'</span>';
			$html .= '<span class="number-icons goUp"><i class="ion-plus"></i></span>';
			$html .= '<span class="number-icons goDown"><i class="ion-minus"></i></span>';
			$html .= '</div>';

//			$html .= '<div class="hb-form-field-input hb-guest-field">';
//			ob_start();
//			hb_dropdown_numbers(
//				array(
//					'name'              => 'max_child',
//					'min'               => 1,
//					'max'               => hb_get_max_child_of_rooms(),
//					'option_none_value' => 0,
//					'selected'          => $max_child,
//					'options'           => hb_get_children_of_rooms()
//				)
//			);
//			$html .= ob_get_clean();
//			$html .= ' <span class="name">'.esc_html__('Children','hotel-wp').'</span>';
//			$html .= '<span class="number-icons goUp2"><i class="ion-plus"></i></span>';
//			$html .= '<span class="number-icons goDown2"><i class="ion-minus"></i></span>';
//			$html .= '</div>';
		$html .= '</div>';
		$html .= '</li>';

		$html .= '</ul>';

		ob_start();
		wp_nonce_field('hb_search_nonce_action', 'nonce');
		$html .= ob_get_clean();

		$html .= '<input type="hidden" name="hotel-booking" value="results" />';
		$html .= '<input type="hidden" name="action" value="hotel_booking_parse_search_params" />';
		$html .= '<p class="hb-submit">';
		$html .= '<span class="contact-info">'.$rooms_search['contact_info'].'</span>';
		$html .= '<button type="submit">' . esc_html__('Check Availability', 'hotel-wp') . '</button>';
		$html .= '</p>';

		$html .= '</form>';
		$html .= '</div>';
	} else {
		ob_start();
		hb_get_template_part( 'tp-hotel-booking/search/search' );
		$html .= ob_get_clean();
	}
	$html .= '</div>';

	return $html;
}

;