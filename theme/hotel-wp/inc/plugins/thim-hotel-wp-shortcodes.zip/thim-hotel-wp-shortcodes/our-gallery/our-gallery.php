<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'Thim_SC_Our_Gallery' ) ) {

	class Thim_SC_Our_Gallery {

		/**
		 * Shortcode name
		 * @var string
		 */
		protected $name = '';

		/**
		 * Shortcode description
		 * @var string
		 */
		protected $description = '';

		/**
		 * Shortcode base
		 * @var string
		 */
		protected $base = '';

		public $count = '';


		public function __construct() {

			//======================== CONFIG ========================
			$this->name        = esc_attr__( 'Thim Our Gallery', 'hotel-wp' );
			$this->description = esc_attr__( 'Display Our Gallery', 'hotel-wp' );
			$this->base        = 'our-gallery';
			//====================== END: CONFIG =====================


			$this->map();
			add_shortcode( 'thim-' . $this->base, array( $this, 'shortcode' ) );

			add_action( 'wp_ajax_thim_sc_our_gallery', array( $this, 'get_list_images' ) );
			add_action( 'wp_ajax_nopriv_thim_sc_our_gallery', array( $this, 'get_list_images' ) );

		}

		/**
		 * vc map shortcode
		 */
		public function map() {
			vc_map( array(
					'name'        => $this->name,
					'base'        => 'thim-' . $this->base,
					'category'    => esc_attr__( 'Thim Shortcodes', 'hotel-wp' ),
					'description' => $this->description,
					'params'      => array(
						array(
							"type"        => "textfield",
							"admin_label" => true,
							"heading"     => esc_attr__( "Title", 'hotel-wp' ),
							"param_name"  => "title",
						),
						array(
							"type"        => "textarea",
							"admin_label" => true,
							"heading"     => esc_attr__( "Sub Title", 'hotel-wp' ),
							"param_name"  => "sub-title",
						),
						array(
							"type"        => "number",
							"min"         => "1",
							"value"       => "6",
							"admin_label" => true,
							"heading"     => esc_attr__( "Limit Posts", 'hotel-wp' ),
							"param_name"  => "limit",
							'description' => esc_attr__( '', 'hotel-wp' )
						),
						array(
							'type'        => 'dropdown',
							'admin_label' => true,
							'heading'     => esc_attr__( 'Items Visible', 'hotel-wp' ),
							'param_name'  => 'item-visible',
							'value'       => array(
								'1' => '1',
								'2' => '2',
								'3' => '3',
								'4' => '4',
								'5' => '5',
								'6' => '6',
								'7' => '7',
								'8' => '8'
							),
							'std'         => '4',
							'description' => esc_attr__( '', 'hotel-wp' )
						),

						array(
							"type"        => "textfield",
							"admin_label" => true,
							"heading"     => esc_attr__( "Image Size", 'hotel-wp' ),
							"param_name"  => "image-size",
							"description" => esc_attr__( "Enter image size (Example: \"thumbnail\", \"medium\", \"large\", \"full\" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).", 'hotel-wp' )
						),

						array(
							"type"        => "checkbox",
							"admin_label" => true,
							"heading"     => esc_attr__( "Show Navigation", 'hotel-wp' ),
							"param_name"  => "show-navigation",
							"description" => esc_attr__( "Show next/prev buttons.", 'hotel-wp' )
						),

						array(
							"type"        => "checkbox",
							"admin_label" => true,
							"heading"     => esc_attr__( "Show Dot", 'hotel-wp' ),
							"param_name"  => "show-dots",
							"description" => esc_attr__( "Show dots navigation.", 'hotel-wp' )
						),

						array(
							"type"        => "number",
							"min"         => "1",
							"value"       => "0",
							"admin_label" => true,
							"heading"     => esc_attr__( "Auto Play Speed (in ms)", 'hotel-wp' ),
							"param_name"  => "auto",
							"description" => esc_attr__( "Set 0 to disable auto play.", 'hotel-wp' )
						),
					)
				)
			);
		}

		/**
		 * Add shortcode
		 *
		 * @param $atts
		 */
		public function shortcode( $atts ) {

			$params = shortcode_atts( array(
				'title'           => '',
				'sub-title'       => '',
				'limit'           => '6',
				'item-visible'    => '4',
				'image-size'      => 'thumbnail',
				'show-navigation' => '',
				'show-dots'       => '',
				'auto'            => '',
			), $atts );

			$params['sc-name'] = $this->base;

			if ( $params['item-visible'] > $params['limit'] ) {
				$params['item-visible'] = $params['limit'];
			}

			$show_post_gallery = array(
				'post_type'      => 'post',
				'posts_per_page' => $params['limit'],
				'tax_query'      => array(
					array(
						'taxonomy' => 'post_format',
						'field'    => 'slug',
						'terms'    => array(
							'post-format-gallery'
						),
					)
				)
			);


			$query = new WP_Query( $show_post_gallery );

			/*$count = count( $query->posts );

			if ( $params['limit'] > $count ) {
				$params['limit'] = $count;
			}*/

			if ( $params['item-visible'] > $params['limit'] ) {
				$params['item-visible'] = $params['limit'];
			}


			ob_start();

			include THIM_SC_PATH . '/our-gallery/tpl/default.php';

			$html = ob_get_contents();
			ob_end_clean();

			return $html;

		}

		public function get_list_images() {
			$current_post_id = !empty( $_POST['post_id'] ) ? $_POST['post_id'] : false;
			if ( !$current_post_id ) {
				return;
			}
			$images = thim_meta( 'thim_gallery', "type=image&single=false&size=full", $current_post_id );

			$new_data = array();
			foreach ( $images as $key => $value ) {
				$value['src'] = $value['url'];
				unset( $value['url'] );
				$new_data[] = $value;
			}
			wp_send_json_success( $new_data );
			die();
		}


	}

	new Thim_SC_Our_Gallery();
}

