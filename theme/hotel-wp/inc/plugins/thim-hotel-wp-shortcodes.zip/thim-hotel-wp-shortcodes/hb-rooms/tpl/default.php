<?php
/**
 * Template for shortcode
 */

add_shortcode( 'thim-hb-rooms', 'thim_shortcode_hb_rooms' );
function thim_shortcode_hb_rooms ( $atts ) {
    $hb_rooms = shortcode_atts( array(

        'number_rooms' => '3',
        'link_text' => '',
        'css_animation' => '',
        'el_class'      => '',

    ), $atts );

    $link         = get_post_type_archive_link( 'hb_room' );
    $css_animation = thim_getCSSAnimation( $hb_rooms['css_animation'] );
    $number_rooms = 3;
    if ( $hb_rooms['number_rooms'] ) {
        $number_rooms = $hb_rooms['number_rooms'];
    }

    $args = array(
        'post_type' => 'hb_room',
        'posts_per_page' => $number_rooms,
        'orderby' => 'date',
        'order' => 'DESC',
    );

    /* remove action */
    remove_action( 'pre_get_posts', 'hotel_booking_num_room_archive', 999 );
    $query = new WP_Query( $args );

    $thim_options  = get_theme_mods();
    $style_room = isset($thim_options['room_style']) ? $thim_options['room_style'] : 'style-1';

    $html = '<div class="thim-sc-hb-rooms '.esc_attr($style_room).' ' . $css_animation . ' ' . esc_attr( $hb_rooms['el_class'] ) . '">';
    if ( $query->have_posts() ):
        
        if ( $hb_rooms['link_text'] == '' ) {
            $html .= '<div class="link-to-rooms">';
            $html .= '</div>';
        }else{
            $html .= '<div class="link-to-rooms">';
            $html .= '<a class="btn-link" href="' . esc_url( $link ) . '"><i class="icomoon icon-up"></i>'. esc_attr( $hb_rooms['link_text'] ) .'</a>';
            $html .= '</div>';
        }


        $html .= '<div class="row rooms tp-hotel-booking hb-catalog-column-'. esc_attr( $number_rooms ) .' '.esc_attr($style_room).'">';
            ob_start();
                while ( $query->have_posts() ) : $query->the_post();

                    hb_get_template_part( 'content', 'room' );

                endwhile;
            $html.= ob_get_clean();

        $html .= '</div>';
    

    else:

        esc_html_e( 'No room found', 'hotel-wp' );

    endif;
    $html .= '</div>';

    wp_reset_postdata();

    /* add action again */
    add_action( 'pre_get_posts', 'hotel_booking_num_room_archive', 999 );

    return $html;

}