<?php
/**
 * @param $css_animation
 *
 * @return string
 */

function thim_getCSSAnimation( $css_animation ) {
	$output = '';
	if ( $css_animation != '' ) {
		wp_enqueue_script( 'waypoints' );
		$output = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}

	return $output;
}

$thim_row_bg_overlay_attributes = array(
	'type'        => 'colorpicker',
	'heading'     => "Background Overlay",
	'param_name'  => 'overlay_color',
	'value'       => '',
	'group'       => 'Advance Options',
);
vc_add_param( 'vc_row', $thim_row_bg_overlay_attributes );

add_filter( 'vc_iconpicker-type-ionicons', 'vc_iconpicker_type_ionicons' );
function vc_iconpicker_type_ionicons( $icons ) {
	$ionicons = array(
		array( 'ion-ribbon-a' => esc_html__( 'ion-ribbon-a', 'hotel-wp' ) ),
		array( 'ion-ios-flower' => esc_html__( 'ion-ios-flower', 'hotel-wp' ) ),
		array( 'ion-ios-nutrition' => esc_html__( 'ion-ios-nutrition', 'hotel-wp' ) ),
		array( 'ion-bonfire' => esc_html__( 'ion-bonfire', 'hotel-wp' ) ),
		array( 'ion-planet' => esc_html__( 'ion-planet', 'hotel-wp' ) ),
		array( 'ion-lightbulb' => esc_html__( 'ion-lightbulb', 'hotel-wp' ) ),
		array( 'ion-cube' => esc_html__( 'ion-cube', 'hotel-wp' ) ),
		array( 'ion-leaf' => esc_html__( 'ion-leaf', 'hotel-wp' ) ),
		array( 'ion-waterdrop' => esc_html__( 'ion-waterdrop', 'hotel-wp' ) ),
		array( 'ion-umbrella' => esc_html__( 'ion-umbrella', 'hotel-wp' ) ),
		array( 'ion-nuclear' => esc_html__( 'ion-nuclear', 'hotel-wp' ) ),
		array( 'ion-person' => esc_html__( 'ion-person', 'hotel-wp' ) ),
		array( 'ion-heart' => esc_html__( 'ion-heart', 'hotel-wp' ) ),
		array( 'ion-briefcase' => esc_html__( 'ion-briefcase', 'hotel-wp' ) ),
		array( 'ion-location' => esc_html__( 'ion-location', 'hotel-wp' ) ),
		array( 'ion-calendar' => esc_html__( 'ion-calendar', 'hotel-wp' ) ),
		array( 'ion-chatbubbles' => esc_html__( 'ion-chatbubbles', 'hotel-wp' ) ),
		array( 'ion-wifi' => esc_html__( 'ion-wifi', 'hotel-wp' ) ),
	);

	return array_merge( $icons, $ionicons );
}

function thim_register_backend_scripts() {
	wp_register_style( 'ionicons', THIM_URI . 'assets/fonts/ionicons/ionicons.css', false, 'screen' );
}
add_action( 'vc_base_register_front_css', 'thim_register_backend_scripts' );
add_action( 'vc_base_register_admin_css', 'thim_register_backend_scripts' );

/**
 * Include backend scripts
 */
function thim_enqueue_backend_scripts() {
	wp_enqueue_style( 'ionicons' );
}

add_action( 'vc_backend_editor_enqueue_js_css', 'thim_enqueue_backend_scripts' );
add_action( 'vc_frontend_editor_enqueue_js_css', 'thim_enqueue_backend_scripts' );

/**
 * Include Simple Line Icons CSS
 */
function thim_enqueue_scripts() {
	wp_enqueue_style( 'th_simplelineicons', THIM_URI . 'assets/fonts/ionicons/ionicons.css', false, 'screen' );
}

add_action( 'init', 'thim_enqueue_scripts' );