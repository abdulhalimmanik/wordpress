<?php
$location     = $params['location'];
$unit     = $params['unit'];
?>

<div id="thim-weather" data-today="<?php echo esc_html__('Today:','hotel-wp'); ?>" data-unit="<?php echo esc_attr($unit); ?>" data-location="<?php echo esc_attr($location); ?>"></div>