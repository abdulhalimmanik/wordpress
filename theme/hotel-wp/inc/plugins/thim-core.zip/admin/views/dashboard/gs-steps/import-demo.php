<div class="top">
	<h2>Import demo content</h2>

	<?php
	do_action( 'thim_dashboard_main_page_importer' );
	do_action( 'thim_importer_modals' );
	?>
</div>

<div class="bottom">
	<button class="button button-primary tc-button tc-run-step">Next</button>
</div>