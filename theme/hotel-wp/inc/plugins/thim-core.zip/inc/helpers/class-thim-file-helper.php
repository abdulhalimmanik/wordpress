<?php

class Thim_File_Helper {

}